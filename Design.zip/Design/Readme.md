# Architecture
## Flow chart
![Flowchart1 (1)](https://user-images.githubusercontent.com/89698000/132567227-09aa32d3-9fd8-46e0-ad41-43367582048a.jpg)
## UML Use case
![Untitled Workspace (5)](https://user-images.githubusercontent.com/89698000/132359625-59a60ead-ddf0-48d5-a03b-39c03fbb2a1d.jpg)
